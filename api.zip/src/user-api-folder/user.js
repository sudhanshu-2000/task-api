const express = require("express");
const app = express.Router();
exports.app = app;
const con = require("../db/conn");
var jwt = require("jsonwebtoken");
var atob = require('atob');
var btoa = require('btoa');
const cors = require("cors");
// app.use(cors({ origin: ['http://localhost:4200'] }));
app.use(cors());
require("dotenv").config();
const bcrypt = require("bcrypt");
var bodyParser = require("body-parser");
var multer = require("multer");
app.use(bodyParser.json({ limit: "50mb" }));
app.use(bodyParser.urlencoded({
  limit: "50mb",
  extended: true,
  parameterLimit: 50000,
}));
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "image/deposit");
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + "-" + uniqueSuffix + ".png");
  },
});
const upload = multer({ storage: storage });

app.post("/register", (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  let codecode = code();
  con.query("SELECT * FROM `user_details` WHERE `mobile` = ?;", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result.length > 0) {
      res.status(302).json(btoa(JSON.stringify({
        error: true,
        status: false,
        message: "Mobile Number is Already Exist",
      })));
    } else {
      con.query("SELECT (IFNULL(MAX(uid),100000)) as id FROM user_details", (err, ides) => {
        if (err) throw err;
        if (result) {
          const hash = bcrypt.hashSync(
            req.body.password,
            bcrypt.genSaltSync(12)
          );
          if (req.body.reffer_by == "" || JSON.stringify(req.body.reffer_by) == "null") {
            con.query("INSERT INTO `user_details`(`mobile`, `username`, `password`, `uid`, `reffer_by`, `reffer_code`) VALUES (?,?,?,?,?,?)",
              [req.body.mobile, req.body.user_name, hash, parseInt(ides[0].id) + 1, 'GJpQpVEO', codecode], (err, result) => {
                if (err) throw err;
                if (result) {
                  con.query("INSERT INTO `wallet`(`user_name`, `wallet_balance`) VALUES (?,?)", [req.body.mobile, 0]);
                  reffer(codecode, 'GJpQpVEO');
                  res.status(200).json(btoa(JSON.stringify({
                    error: false,
                    status: true,
                    message: "Registered Successfully",
                  })));
                }
              }
            );
          }
          else {
            con.query("select * from user_details where `reffer_code` = ?", [req.body.reffer_by], (err, result) => {
              if (err) throw err;
              if (result.length > 0) {
                con.query("INSERT INTO `user_details`(`mobile`, `username`, `password`, `uid`, `reffer_by`, `reffer_code`) VALUES (?,?,?,?,?)",
                  [req.body.mobile, req.body.user_name, hash, parseInt(ides[0].id) + 1, req.body.reffer_by, codecode], (err, result) => {
                    if (err) throw err;
                    if (result) {
                      con.query("INSERT INTO `wallet`(`user_name`, `wallet_balance`) VALUES (?,?)", [req.body.mobile, 0]);
                      reffer(codecode, req.body.reffer_by);
                      res.status(200).json(btoa(JSON.stringify({
                        error: false,
                        status: true,
                        message: "Registered Successfully",
                      })));
                    }
                  }
                );
              } else {
                res.status(404).json(btoa(JSON.stringify({
                  error: false,
                  status: true,
                  message: "This refferal Code is not valid.",
                })));
              }
            })
          }
        }
      });
    }
  }
  );
});
app.post("/login", (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "select * from user_details where mobile = ?",
    [req.body.mobile],
    (err, result) => {
      if (err) throw err;
      if (result.length > 0) {
        const status = bcrypt.compareSync(
          req.body.password,
          result[0].password
        );
        if (status == true) {
          var token = jwt.sign(
            { username: result[0].mobile },
            process.env.SECRET_KEY_USER, { expiresIn: '30d' },
          );
          con.query("UPDATE `user_details` SET `is_active` = 'Y' WHERE `mobile` = ?", [req.body.mobile], (err, resulrt) => {
            if (err) { throw err; }
            if (resulrt) {
              res.status(200).json(btoa(JSON.stringify({
                error: false,
                status: true,
                ID: result[0].uid,
                username: result[0].mobile,
                message: "Login Successfully",
                token,
              })));
            }
          })
        } else {
          res.status(404).json(btoa(JSON.stringify({
            error: true,
            status: false,
            message: "Mobile Or Password is Wrong",
          })));
        }
      } else {
        res.status(404).json(btoa(JSON.stringify({
          error: true,
          message: "Mobile Number is Not Exist",
        })));
      }
    }
  );
});
app.post("/logout", (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("UPDATE `user_details` SET `is_active` = 'N' WHERE `mobile` = ?", [req.body.mobile], (err, result) => {
    if (err) { throw err; }
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true })));
    }
  })
});
app.post('/choose-plan', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "UPDATE `user_details` SET `plan_type` = ? WHERE `mobile` = ?",
    [req.body.plan_id, req.body.mobile],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res.status(200).json(btoa(JSON.stringify({
          error: false,
          status: true
        })));
      }
    }
  );
})
app.post("/get-plans", (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("select * from `plan`", (err, result) => {
    if (err) {
      throw err;
    }
    if (result) {
      res.status(200).json(btoa(JSON.stringify({
        error: false,
        status: true,
        data: result
      })));
    }
  })
})
app.post("/change", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("select * from user_details where `mobile` = ?", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      const status = bcrypt.compareSync(
        req.body.password,
        result[0].password
      );
      if (status == true) {
        const hash = bcrypt.hashSync(
          req.body.new_password,
          bcrypt.genSaltSync(12)
        );
        con.query(
          "UPDATE `user_details` SET `password` = ? WHERE `mobile` = ?",
          [hash, req.body.mobile],
          (err, result) => {
            if (err) throw err;
            if (result) {
              res.status(200).json(btoa(JSON.stringify({
                error: false,
                status: true,
                message: "Reset Password Successfully",
              })));
            }
          }
        );
      } else {
        res.status(200).json(btoa(JSON.stringify({
          error: true,
          message: "Password is Wrong",
        })));
      }
    }
  }
  );
});

app.post("/wallet-balance", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "SELECT * FROM `wallet` WHERE user_name = ?",
    [req.body.mobile],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res.status(200).json(btoa(JSON.stringify({
          error: false,
          status: "Success",
          data: result
        })));
      }
    }
  );
});

app.post("/withdrawal-balace", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "SELECT `wallet_balance` FROM `wallet` WHERE user_name = ?",
    [req.body.mobile],
    (err, result) => {
      if (err) throw err;
      if (result) {
        con.query(
          "UPDATE `wallet` SET `wallet_balance` = ?, WHERE mobile = ?",
          req.body.wallet,
          (err, result) => {
            if (err) {
              throw err;
            }
            if (result.length > 0) {
              res.status(200).json(btoa(JSON.stringify({
                error: false,
                status: true,
                msg: "your wallet is update",
              })));
            } else {
              res.status(403).json(btoa(JSON.stringify({
                error: false,
                status: true,
                msg: "your wallet is not a update",
              })));
            }
          }
        );
      }
    }
  );
});
app.post("/get-game-type", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("select * from `game_type`", (err, result) => {
    if (err) throw err;
    else {
      res.status(200).json(btoa(JSON.stringify({ data: result })));
    }
  });
});
app.post("/get-otp", (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  const val = Math.floor(1000 + Math.random() * 9000);
  const hash = bcrypt.hashSync(val.toString(), bcrypt.genSaltSync(12));
  con.query(
    "SELECT * FROM `otp` WHERE `number` = ?",
    [req.body.number],
    (err, result) => {
      if (err) throw err;
      if (result.length > 0) {
        con.query(
          "UPDATE `otp` SET `otp` = ? WHERE `number` = ?",
          [hash, req.body.number],
          (err, result) => {
            if (err) throw err;
            if (result) {
              res.status(200).json(btoa(JSON.stringify({
                number: req.body.number,
                otp: val.toString(),
              })));
            }
          }
        );
      } else {
        con.query(
          "INSERT INTO `otp`(`otp`, `number`) VALUES (?,?)",
          [hash, req.body.number],
          (err, result) => {
            if (err) throw err;
            if (result) {
              res.status(200).json(btoa(JSON.stringify({
                number: req.body.number,
                otp: val.toString(),
              })));
            }
          }
        );
      }
    }
  );
});
app.post("/verify-otp", (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "SELECT * FROM `otp` where number = ?",
    [req.body.number],
    (err, result) => {
      if (err) throw err;
      if (result.length > 0) {
        const match = bcrypt.compareSync(req.body.otp, result[0].otp);
        if (match == true) {
          res.status(200).json(btoa(JSON.stringify({
            error: false,
            status: true,
            msg: "Verify OTP",
          })));
        } else {
          res.status(404).json(btoa(JSON.stringify({
            error: true,
            status: false,
            msg: "Wrong OTP",
          })));
        }
      } else {
        res.status(200).json(btoa(JSON.stringify({
          error: true,
          status: false,
          msg: "number is not exist",
        })));
      }
    }
  );
});
app.post("/get-record-complete", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  let limit = 20;
  let offset = limit * req.body.page - limit;
  con.query(
    "SELECT r.*, (SELECT COUNT(*)  FROM `record` WHERE `status` = 'Y' and `game_type` = ?) as count, (SELECT code from game_color WHERE id = gm.color_id) as color_code FROM `record` as r  INNER JOIN game_number as gn on r.number = gn.number INNER join game_mapping as gm on gm.number_id = gn.id and gm.game_type_id = r.game_type WHERE r.`status` = 'Y' and r.`game_type` = ?  GROUP by r.period ORDER BY id DESC LIMIT ? OFFSET ?",
    [req.body.id, req.body.id, limit, offset],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res.status(200).json(btoa(JSON.stringify({
          error: false,
          status: true,
          data: result,
        })));
      }
    }
  );
});
app.post("/get-record-complete-details", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  // if(req.body.page === 0){
  let limit = 10;
  let offset = limit * req.body.page - limit;
  con.query(
    "SELECT r.*, (SELECT COUNT(*)  FROM `record` WHERE `status` = 'Y' and `game_type` = ?) as count, (SELECT code from game_color WHERE id= gm.color_id) as color_code FROM `record` as r  INNER JOIN game_number as gn on r.number = gn.number INNER join game_mapping as gm on gm.number_id = gn.id and gm.game_type_id = r.game_type WHERE r.`status` = 'Y' and r.`game_type` = ?  GROUP by r.period ORDER BY id DESC LIMIT ? OFFSET ?",
    [req.body.id, req.body.id, limit, offset],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res.status(200).json(btoa(JSON.stringify({
          error: false,
          status: true,
          data: result,
        })));
      }
    }
  );
});
app.post("/get-record-not-complete", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "SELECT `period`, `game_type`, `start_date`, `end_date` FROM `record` WHERE `status` = 'N' and `game_type` = ?",
    [req.body.id],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res.status(200).json(btoa(JSON.stringify({
          error: false,
          status: true,
          data: result,
        })));
      }
    }
  );
});
app.post("/get-game-mapping-number", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "SELECT gm.id, gt.id as game_type, gc.code as color_code, gn.number as number FROM game_mapping gm INNER JOIN game_color gc ON gc.id = gm.color_id INNER JOIN game_number gn ON gn.id = gm.number_id INNER JOIN game_type gt ON gt.id = gm.game_type_id where game_type_id= ? ORDER BY CAST(number AS UNSIGNED INTEGER);",
    [req.body.id],
    (err, result_data) => {
      if (err) throw err;
      if (result_data) orders = result_data;
      const grouped = {};
      for (const {
        color_code,
        color_name,
        date,
        for_color_or_number,
        game_type,
        id,
        number,
        status,
      } of orders) {
        const userGroup = (grouped[number] ??= {
          number,
          color_name,
          date,
          for_color_or_number,
          game_type,
          id,
          status,
          orders: {},
        });
        const bookGroup = (userGroup.orders[color_code] ??= { color_code });
      }
      newdata = Object.values(grouped).map(({ orders, ...rest }) => ({
        ...rest,
        orders: Object.values(orders),
      }));
      res.status(200).json(btoa(JSON.stringify({ data: newdata })));
    }
  );
});
app.post("/get-game-mapping-color", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "SELECT gm.id, gm.for_color_or_number, gt.id as game_type,gc.name as color_name, gc.code as color_code ,gm.status, gm.date FROM game_mapping gm INNER JOIN game_color gc ON gc.id = gm.color_id INNER JOIN game_type gt ON gt.id = gm.game_type_id where gm.for_color_or_number= 'only_color' and game_type_id = ?",
    [req.body.id],
    (err, result) => {
      if (err) throw err;
      if (result) res.status(200).json(btoa(JSON.stringify({ data: result })));
    }
  );
});
app.post("/get-pay-method", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "SELECT * FROM `payment_method` WHERE status = 'y'",
    [req.body.id],
    (err, result) => {
      if (err) throw err;
      if (result)
        res.status(200).json(btoa(JSON.stringify({
          error: false,
          status: true,
          data: result,
        })));
    }
  );
});
app.post("/get-pay-deatils", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "SELECT cpd.id, cpd.mobile_no, cpm.name as pname, cpd.name, cpd.UPI_id, cpd.QR_code, cpd.bank_name, cpd.account_no, cpd.ifsc_code, cpd.account_type, cpm.icon, cpd.status, cpd.date FROM colorgame.`payment_details` as cpd inner join colorgame.payment_method as cpm on cpd.paymethod_id = cpm.id where cpd.status = 'Y' and cpd.paymethod_id = ?;",
    [req.body.id],
    (err, result) => {
      if (err) throw err;
      if (result)
        res.status(200).json(btoa(JSON.stringify({
          error: false,
          status: true,
          data: result,
        })));
    }
  );
});
app.post("/user-details", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "SELECT cw.id, cw.user_name, cw.wallet_balance, cw.winning_wallet, cw.Bonus_wallet, cu.uid, cu.status, cu.date FROM colorgame.wallet cw join colorgame.user_details cu on cw.user_name = cu.user_name  where cw.user_name = ? order by id;",
    [req.body.mobile],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res.status(200).json(btoa(JSON.stringify({
          error: false,
          stutus: true,
          data: result,
        })));
      }
    }
  );
});

// check
app.post("/get-check", (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT * FROM `check` WHERE `user_id` = ?", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ data: result })));
    }
  });
});
app.post("/add-check", (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT * FROM `check` WHERE `user_id` = ?", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ data: result })));
    }
  });
});

// bet-record
app.post("/get-bet-record", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  let limit = 10;
  let offset = limit * req.body.page - limit;
  con.query(
    "SELECT bt.`id`, bt.`Period`, bt.`game-type`, bt.`price`, bt.`type`, bt.`value`, bt.if_open_zero, (SELECT code from game_color where id = gm.color_id)as color, (SELECT COUNT(*) FROM `bet-table` WHERE `username` = ? and `game-type` = ?) as count, (SELECT `number` FROM `record` WHERE `period` = bt.`Period` and `game_type` = bt.`game-type` LIMIT 1 OFFSET 0) as number, (SELECT (SELECT (SELECT (SELECT gc.name FROM game_color as gc WHERE gc.id = gmin.color_id) FROM game_mapping as gmin WHERE gmin.number_id = gnum.id AND gmin.game_type_id = r.game_type ORDER BY gmin.id ASC LIMIT 1) from game_number as gnum WHERE gnum.number = r.number) FROM `record` as r WHERE r.`period` = bt.`Period` and r.`game_type` = bt.`game-type` LIMIT 1 OFFSET 0) as open_color,(SELECT `winning-amount` FROM `record` WHERE `period` = bt.`Period` and `game_type` = bt.`game-type` LIMIT 1 OFFSET 0) as winning_amount FROM `bet-table` as bt INNER JOIN game_mapping as gm on bt.value_id = gm.id WHERE bt.`username` = ? and bt.`game-type` = ? ORDER by id DESC LIMIT ? OFFSET ?;",
    [req.body.mobile, req.body.id, req.body.mobile, req.body.id, limit, offset],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res.status(200).json(btoa(JSON.stringify({
          error: false,
          status: true,
          data: result,
        })));
      }
    }
  );
});
app.post("/add-bet-details", (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  if (req.body.bonuscheck == true) {
    let value = parseInt(req.body.total_amount) - (parseInt(req.body.total_amount) / 10);
    con.query("SELECT IF(`wallet_balance` + `Winning_wallet` + (IF(`Bonus_wallet` >= ?, ?, 0)) >= ?, IF(wallet_balance >= ?, 'true', wallet_balance), 'wfalse') AS result FROM wallet WHERE `user_name` = ?;",
      [(parseInt(req.body.total_amount) / 10), (parseInt(req.body.total_amount) / 10), parseInt(req.body.total_amount), value, req.body.mobile], (error, result) => {
        if (error) {
          throw error;
        }
        if (result[0].result === "wfalse") {
          res.status(302).json(btoa(JSON.stringify({
            error: true,
            status: false,
            massage: "Insufficient Balance in your Account",
          })));
        } else if (result[0].result === "true") {
          con.query("UPDATE `wallet` SET `wallet_balance` = `wallet_balance` - ?, `Bonus_wallet` = `Bonus_wallet` - ? WHERE `user_name` = ?",
            [value, (parseInt(req.body.total_amount) / 10), req.body.mobile],
            (err, resultt) => {
              if (err) throw err;
              if (resultt) {
                con.query("INSERT INTO `bet-table`(`Period`, `username`, `price`, `type`, `winning-amount`, `if_open_zero`, `value`, `value_id`, `game-type`, `term_condition`) VALUES (?,?,?,?,(SELECT `multiple` FROM `game_mapping` WHERE `id` = ?) * ?, (SELECT `if_open_zero` FROM `game_mapping` WHERE `id` = ?) * ?, ?, ?, ?, 'Y')",
                  [
                    req.body.period,
                    req.body.mobile,
                    req.body.total_amount,
                    req.body.method,
                    req.body.id,
                    req.body.total_amount,
                    req.body.id,
                    req.body.total_amount,
                    req.body.select,
                    req.body.id,
                    req.body.game_type,
                  ],
                  (err, resultt) => {
                    if (err) throw err;
                    if (resultt) {
                      con.query("INSERT INTO `statement`(`username`, `bet_or_type`, `period`, `Select`, `bet_from`, `bet_balance`, `total_balance`, `status`) VALUES (?, (SELECT `name` FROM `game_type` WHERE `id` = ?), ?, ?, 'Deposit Wallet & Bonus Wallet', ?, (SELECT (`wallet_balance` + `Winning_wallet` + `Bonus_wallet`) as balance FROM `wallet` WHERE `user_name` = ?), 'Bet Add')",
                        [
                          req.body.mobile,
                          req.body.game_type,
                          req.body.period,
                          req.body.select,
                          req.body.total_amount,
                          req.body.mobile
                        ],
                        (errr, resu) => {
                          if (errr) {
                            throw errr;
                          }
                          if (resu) {
                            res.status(200).json(btoa(JSON.stringify({
                              error: false,
                              status: true,
                            })));
                          }
                        })
                    }
                  }
                );
              }
            }
          );
        } else {
          let WB = value - result[0].result;
          con.query("UPDATE `wallet` SET `wallet_balance` = `wallet_balance` - ?, `Winning_wallet` = `Winning_wallet` - ?, `Bonus_wallet` = `Bonus_wallet` - ? WHERE `user_name` = ?",
            [parseInt(result[0].result), WB, (parseInt(req.body.total_amount) / 10), req.body.mobile],
            (err, resultt) => {
              if (err) throw err;
              if (resultt) {
                con.query("INSERT INTO `bet-table`(`Period`, `username`, `price`, `type`, `winning-amount`, `if_open_zero`, `value`, `value_id`, `game-type`, `term_condition`) VALUES (?, ?, ?, ?, (SELECT `multiple` FROM `game_mapping` WHERE `id` = ?) * ?, (SELECT `if_open_zero` FROM `game_mapping` WHERE `id` = ?) * ?, ?, ?, ?, 'Y')",
                  [
                    req.body.period,
                    req.body.mobile,
                    req.body.total_amount,
                    req.body.method,
                    req.body.id,
                    req.body.total_amount,
                    req.body.id,
                    req.body.total_amount,
                    req.body.select,
                    req.body.id,
                    req.body.game_type,
                  ],
                  (err, resultt) => {
                    if (err) throw err;
                    if (resultt) {
                      con.query("INSERT INTO `statement`(`username`, `bet_or_type`, `period`, `Select`, `bet_from`, `bet_balance`, `total_balance`, `status`) VALUES (?, (SELECT `name` FROM `game_type` WHERE `id` = ?), ?, ?, 'Deposit Wallet & Bonus Wallet', ?, (SELECT (`wallet_balance` + `Winning_wallet` + `Bonus_wallet`) as balance FROM `wallet` WHERE `user_name` = ?), 'Bet Add')",
                        [
                          req.body.mobile,
                          req.body.game_type,
                          req.body.period,
                          req.body.select,
                          req.body.total_amount,
                          req.body.mobile
                        ],
                        (errr, resu) => {
                          if (errr) {
                            throw errr;
                          }
                          if (resu) {
                            res.status(200).json(btoa(JSON.stringify({
                              error: false,
                              status: true,
                            })));
                          }
                        })
                    }
                  }
                );
              }
            }
          );
        }
      }
    )
  } else {
    con.query("SELECT IF(`wallet_balance` + `Winning_wallet` >= ?, IF(wallet_balance >= ?, 'true', wallet_balance), 'wfalse') AS result FROM wallet WHERE `user_name` = ?;",
      [parseInt(req.body.total_amount), parseInt(req.body.total_amount), req.body.mobile], (error, result) => {
        if (error) {
          throw error;
        }
        if (result[0].result === "wfalse") {
          res.status(302).json(btoa(JSON.stringify({
            error: true,
            status: false,
            massage: "Insufficient Balance in your Account",
          })));
        } else if (result[0].result === "true") {
          const percentage2 = ((2 / 100) * parseFloat(req.body.total_amount));
          const total_amount = parseFloat(req.body.total_amount) - percentage2;
          agent(percentage2, req.body.mobile);
          con.query("UPDATE `wallet` SET `wallet_balance` = `wallet_balance` - ? WHERE `user_name` = ?",
            [parseInt(total_amount), req.body.mobile], (err, resultt) => {
              if (err) throw err;
              if (resultt) {
                con.query("INSERT INTO `bet-table`(`Period`, `username`, `price`, `type`, `winning-amount`, `if_open_zero`, `value`, `value_id`, `game-type`, `term_condition`) VALUES (?, ?, ?, ?, (SELECT `multiple` FROM `game_mapping` WHERE `id` = ? ) * ?, (SELECT `if_open_zero` FROM `game_mapping` WHERE `id` = ?) * ?, ?, ?, ?, 'Y')",
                  [
                    req.body.period,
                    req.body.mobile,
                    total_amount,
                    req.body.method,
                    req.body.id,
                    total_amount,
                    req.body.id,
                    total_amount,
                    req.body.select,
                    req.body.id,
                    req.body.game_type,
                  ],
                  (err, resultt) => {
                    if (err) throw err;
                    if (resultt) {
                      con.query("INSERT INTO `statement`(`username`, `bet_or_type`, `period`, `Select`, `bet_from`, `bet_balance`, `total_balance`, `status`) VALUES (?, (SELECT `name` FROM `game_type` WHERE `id` = ?), ?, ?, 'Deposit Wallet & Bonus Wallet', ?, (SELECT (`wallet_balance` + `Winning_wallet` + `Bonus_wallet`) as balance FROM `wallet` WHERE `user_name` = ?), 'Bet Add')",
                        [
                          req.body.mobile,
                          req.body.game_type,
                          req.body.period,
                          req.body.select,
                          total_amount,
                          req.body.mobile
                        ],
                        (errr, resu) => {
                          if (errr) {
                            throw errr;
                          }
                          if (resu) {
                            res.status(200).json(btoa(JSON.stringify({
                              error: false,
                              status: true,
                            })));
                          }
                        })
                    }
                  }
                );
              }
            }
          );
        } else {
          const percentage = ((2 / 100) * parseFloat(req.body.total_amount));
          const total_amount = parseFloat(req.body.total_amount) - percentage;
          agent(percentage, req.body.mobile);
          con.query("UPDATE `wallet` SET `wallet_balance` = `wallet_balance` - ?, `Winning_wallet` = `Winning_wallet` - ? WHERE `user_name` = ?",
            [parseInt(result[0].result), (parseInt(total_amount) - parseInt(result[0].result)), req.body.mobile],
            (err, resultt) => {
              if (err) throw err;
              if (resultt) {
                con.query("INSERT INTO `bet-table`(`Period`, `username`, `price`, `type`, `winning-amount`, `if_open_zero`, `value`, `value_id`, `game-type`, `term_condition`) VALUES (?, ?, ?, ?, (SELECT `multiple` FROM `game_mapping` WHERE `id` = ?) * ?, (SELECT `if_open_zero` FROM `game_mapping` WHERE `id` = ?) * ?, ?, ?, ?, 'Y')",
                  [
                    req.body.period,
                    req.body.mobile,
                    total_amount,
                    req.body.method,
                    req.body.id,
                    total_amount,
                    req.body.id,
                    total_amount,
                    req.body.select,
                    req.body.id,
                    req.body.game_type,
                  ],
                  (err, resultt) => {
                    if (err) throw err;
                    if (resultt) {
                      con.query("INSERT INTO `statement`(`username`, `bet_or_type`, `period`, `Select`, `bet_from`, `bet_balance`, `total_balance`, `status`) VALUES (?, (SELECT `name` FROM `game_type` WHERE `id` = ?), ?, ?, 'Deposit Wallet & Bonus Wallet', ?, (SELECT (`wallet_balance` + `Winning_wallet` + `Bonus_wallet`) as balance FROM `wallet` WHERE `user_name` = ?), 'Bet Add')",
                        [
                          req.body.mobile,
                          req.body.game_type,
                          req.body.period,
                          req.body.select,
                          total_amount,
                          req.body.mobile
                        ],
                        (errr, resu) => {
                          if (errr) {
                            throw errr;
                          }
                          if (resu) {
                            res.status(200).json(btoa(JSON.stringify({
                              error: false,
                              status: true,
                            })));
                          }
                        })
                    }
                  }
                );
              }
            }
          );
        }
      }
    )
  }
});

app.post("/deposit-request", upload.single("d_image"), verifytoken, (req, res) => {
  con.query("select cpd.id from colorgame.payment_details as cpd inner join colorgame.payment_method as cpm on cpd.paymethod_id = cpm.id where cpd.status = 'Y' and cpm.name = ?;",
    [req.body.pay_method],
    (err, pay1) => {
      if (err) throw err;
      if (pay1.length > 0) {
        if (req.body.coupon == "") {
          con.query(
            "INSERT INTO `deposit`(`user_name`, `balance`, `image`, `payment`, `coupan`, `paymethod_id`) VALUES (?,?,?,?,?,?)",
            [
              req.body.mobile,
              req.body.balance,
              req.file.filename,
              req.body.pay_method,
              req.body.coupon,
              pay1[0].id,
            ],
            (err, result) => {
              if (err) throw err;
              if (result) {
                res.status(201).json(btoa(JSON.stringify({
                  error: false,
                  status: true,
                  massage: "Add Deposit Request",
                })));
              }
            }
          );
        } else
          con.query(
            "SELECT * FROM `payment_bonus` WHERE `offer_name` = ? and `status` = 'Y'",
            [req.body.coupon],
            (err, pay) => {
              if (err) throw err;
              if (pay.length > 0) {
                con.query(
                  "INSERT INTO `deposit`(`user_name`, `balance`, `image`, `payment`, `coupan`, `paymethod_id`) VALUES (?,?,?,?,?,?)",
                  [
                    req.body.mobile,
                    req.body.balance,
                    req.file.filename,
                    req.body.pay_method,
                    req.body.coupon,
                    pay1[0].id,
                  ],
                  (err, result) => {
                    if (err) throw err;
                    if (result) {
                      res.status(201).json(btoa(JSON.stringify({
                        error: false,
                        status: true,
                        massage: "Add Deposit Request",
                      })));
                    }
                  }
                );
              } else {
                res.status(302).json(btoa(JSON.stringify({
                  error: true,
                  stutus: false,
                  massage: "Invalid Coupon Code",
                })));
              }
            }
          );
      }
    }
  );
});
app.post("/get-deposit-request", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  if (req.body.status === "Pending") {
    con.query(
      "SELECT cd.id, cd.user_name, cd.image, cd.transaction_id, cd.reason, cd.payment, cd.balance, cd.coupan, cd.status, cp.name as holder_name, cp.account_no, cp.account_type, cp.bank_name, cp.ifsc_code, cp.UPI_id, cd.date FROM colorgame.`deposit` as cd inner join colorgame.payment_details as cp on cd.paymethod_id = cp.id WHERE cd.`status` = 'Pending' and cd.`user_name` = ?;",
      [req.body.mobile],
      (err, result) => {
        if (err) throw err;
        if (result) {
          res.status(200).json(btoa(JSON.stringify({
            error: false,
            status: true,
            data: result,
          })));
        }
      }
    );
  } else if (req.body.status === "Success") {
    con.query(
      "SELECT cd.id, cd.user_name, cd.image, cd.transaction_id, cd.reason, cd.payment, cd.balance, cd.coupan, cd.status, cp.name as holder_name, cp.account_no, cp.account_type, cp.bank_name, cp.ifsc_code, cp.UPI_id, cd.date FROM colorgame.`deposit` as cd inner join colorgame.payment_details as cp on cd.paymethod_id = cp.id WHERE cd.`status` = 'Success' and cd.`user_name` = ?;",
      [req.body.mobile],
      (err, result) => {
        if (err) throw err;
        if (result) {
          res.status(200).json(btoa(JSON.stringify({
            error: false,
            status: true,
            data: result,
          })));
        }
      }
    );
  } else if (req.body.status === "Canceled") {
    con.query(
      "SELECT cd.id, cd.user_name, cd.image, cd.transaction_id, cd.reason, cd.payment, cd.balance, cd.coupan, cd.status, cp.name as holder_name, cp.account_no, cp.account_type, cp.bank_name, cp.ifsc_code, cp.UPI_id, cd.date FROM colorgame.`deposit` as cd inner join colorgame.payment_details as cp on cd.paymethod_id = cp.id WHERE cd.`status` = 'Canceled' and cd.`user_name` = ?;",
      [req.body.mobile],
      (err, result) => {
        if (err) throw err;
        if (result) {
          res.status(200).json(btoa(JSON.stringify({
            error: false,
            status: true,
            data: result,
          })));
        }
      }
    );
  } else {
    con.query(
      "SELECT cd.id, cd.user_name, cd.image, cd.transaction_id, cd.reason, cd.payment, cd.balance, cd.status, cd.coupan, cp.name as holder_name, cp.account_no, cp.account_type, cp.bank_name, cp.ifsc_code, cp.UPI_id, cd.date FROM colorgame.`deposit` as cd inner join colorgame.payment_details as cp on cd.paymethod_id = cp.id where cd.`user_name` = ?;",
      [req.body.mobile],
      (err, result) => {
        if (err) throw err;
        if (result) {
          res.status(200).json(btoa(JSON.stringify({
            error: false,
            status: true,
            data: result,
          })));
        }
      }
    );
  }
});

//Bank Deatils
app.post("/add-bankdetails", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "select * from userbankdeatils where account_no = ?",
    [req.body.account_no],
    (err, result) => {
      if (err) throw err;
      if (result.length > 0) {
        res.status(302).json(btoa(JSON.stringify({
          error: true,
          status: false,
          massage: "Account No is already exist",
        })));
      } else {
        con.query(
          "INSERT INTO `userbankdeatils`(`username`, `account_no`, `ifsc_code`, `account_holder_name`, `bankname`, `account_type`) VALUES (?,?,?,?,?,?)",
          [
            req.body.mobile,
            req.body.account_no,
            req.body.ifsc,
            req.body.name,
            req.body.bankname,
            req.body.account_type,
          ],
          (errr, resultt) => {
            if (errr) throw errr;
            if (resultt) {
              res.status(201).json(btoa(JSON.stringify({
                error: false,
                status: true,
                massage: "Add bank deatils, Wait for Varification",
              })));
            }
          }
        );
      }
    }
  );
});
app.post("/get-bankdetails", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "SELECT `id`, `username`, `account_no`, `ifsc_code`, `account_holder_name`, `bankname`, `account_type`, `status`, `reason`, `date` FROM `userbankdeatils` WHERE `username` = ?",
    [req.body.mobile],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })));
      }
    }
  );
});
app.post("/delete-bankdetails", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "DELETE FROM `userbankdeatils` WHERE `id` = ?",
    [req.body.id],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res
          .status(200)
          .json(btoa(JSON.stringify({ error: false, status: true, massge: "Deleted Successfully" })));
      }
    }
  );
});

//number Deatils
app.post("/add-numberdetails", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "SELECT * FROM `usernumberdetails` WHERE `number` = ? and `type` = ?",
    [req.body.number, req.body.type],
    (err, result) => {
      if (err) throw err;
      if (result.length > 0) {
        res.status(302).json(btoa(JSON.stringify({
          error: true,
          status: false,
          massage: "Mobile No is already exist",
        })));
      } else {
        con.query(
          "INSERT INTO `usernumberdetails`(`username`, `name`, `type`, `number`) VALUES (?,?,?,?)",
          [req.body.mobile, req.body.name, req.body.type, req.body.number],
          (errr, resultt) => {
            if (errr) throw errr;
            if (resultt) {
              res.status(201).json(btoa(JSON.stringify({
                error: false,
                status: true,
                massage: "Added Successfully",
              })));
            }
          }
        );
      }
    }
  );
});
app.post("/get-numberetails", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "SELECT * FROM `usernumberdetails` WHERE `username` = ?",
    [req.body.mobile],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })));
      }
    }
  );
});
app.post("/delete-numberetails", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "DELETE FROM `usernumberdetails` WHERE `id` = ?",
    [req.body.id],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res
          .status(200)
          .json(btoa(JSON.stringify({ error: false, status: true, massge: "Deleted Successfully" })));
      }
    }
  );
});

//UPI Details
app.post("/add-upidetails", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "SELECT * FROM `userupidetails` WHERE `UPI_id` = ?",
    [req.body.upiid],
    (err, result) => {
      if (err) throw err;
      if (result.length > 0) {
        res.status(302).json(btoa(JSON.stringify({
          error: true,
          status: false,
          massage: "UPI Id is already exist",
        })));
      } else {
        con.query(
          "INSERT INTO `userupidetails`( `username`, `name`, `UPI_id`) VALUES (?,?,?)",
          [req.body.mobile, req.body.name, req.body.upiid],
          (errr, resultt) => {
            if (errr) throw errr;
            if (resultt) {
              res.status(201).json(btoa(JSON.stringify({
                error: false,
                status: true,
                massage: "Added Successfully",
              })));
            }
          }
        );
      }
    }
  );
});
app.post("/get-upidetails", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "SELECT * FROM `userupidetails` WHERE `username` = ?",
    [req.body.mobile],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })));
      }
    }
  );
});
app.post("/delete-upidetails", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "DELETE FROM `userupidetails` WHERE `id` = ?",
    [req.body.id],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res
          .status(200)
          .json(btoa(JSON.stringify({ error: false, status: true, massge: "Deleted Successfully" })));
      }
    }
  );
});

//withdrawal Deatils
app.post("/add-withdrawal-request", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  if (299 > parseInt(req.body.amount)) {
    res.status(302).json(btoa(JSON.stringify({
      error: true,
      status: false,
      massage: "Minimum Balance withdrawal is 300 ",
    })));
  } else {
    con.query(
      "SELECT IF(`Winning_wallet` >= ?, 'true', 'false') as result FROM wallet WHERE `user_name` = ?; ",
      [parseInt(req.body.amount), req.body.mobile],
      (error, result) => {
        if (error) {
          throw error;
        }
        if (result[0].result === "true") {
          con.query(
            "UPDATE `wallet` SET `Winning_wallet` = `Winning_wallet` - ? WHERE `user_name` = ?",
            [parseInt(req.body.amount), req.body.mobile],
            (err, resultt) => {
              if (err) throw err;
              if (resultt) {
                con.query(
                  "INSERT INTO `withdrawal`(`user_name`, `balance`, `paymethod_id`, `paytype`) VALUES (?,?,?,?)",
                  [
                    req.body.mobile,
                    req.body.amount,
                    req.body.id,
                    req.body.method,
                  ],
                  (err, resultt) => {
                    if (err) throw err;
                    if (resultt) {
                      res.status(200).json(btoa(JSON.stringify({
                        error: false,
                        status: true,
                        massage: "Added withdrawal Request SuccessFully",
                      })));
                    }
                  }
                );
              }
            }
          );
        } else {
          res.status(302).json(btoa(JSON.stringify({
            error: true,
            status: false,
            massage: "Insufficient Balance in your Winning wallet",
          })));
        }
      }
    );
  }
});
app.post("/get-withdrawal-request", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  if (req.body.status === "Pending") {
    con.query(
      "SELECT w.id, w.user_name, w.balance, w.reason, b.account_no, b.account_holder_name, b.account_type, b.bankname, b.ifsc_code, upi.name as upiname, upi.UPI_id, num.name, num.number, w.paytype, W.status, w.date  FROM colorgame.withdrawal as w left JOIN colorgame.userbankdeatils as b ON CASE WHEN w.paytype = 'Bank Transfer' THEN w.paymethod_id = b.id ELSE NULL END left JOIN colorgame.userupidetails as upi ON CASE WHEN w.paytype = 'UPI Id' THEN w.paymethod_id = upi.id ELSE NULL END left JOIN colorgame.usernumberdetails as num ON CASE WHEN w.paytype = 'Number' THEN w.paymethod_id = num.id ELSE NULL END where w.user_name = ? and w.status = 'Pending'",
      [req.body.mobile],
      (err, result) => {
        if (err) throw err;
        if (result) {
          res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })));
        }
      }
    );
  } else if (req.body.status === "Success") {
    con.query(
      "SELECT w.id, w.user_name, w.balance, w.reason, b.account_no, b.account_holder_name, b.account_type, b.bankname, b.ifsc_code,upi.name as upiname, upi.UPI_id, num.name, num.number, w.paytype, W.status, w.date FROM colorgame.withdrawal as w left JOIN colorgame.userbankdeatils as b ON CASE WHEN w.paytype = 'Bank Transfer' THEN w.paymethod_id = b.id ELSE NULL END left JOIN colorgame.userupidetails as upi ON CASE WHEN w.paytype = 'UPI Id' THEN w.paymethod_id = upi.id ELSE NULL END left JOIN colorgame.usernumberdetails as num ON CASE WHEN w.paytype = 'Number' THEN w.paymethod_id = num.id ELSE NULL END where w.user_name = ? and w.status = 'Success'",
      [req.body.mobile],
      (err, result) => {
        if (err) throw err;
        if (result) {
          res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })));
        }
      }
    );
  } else if (req.body.status === "Canceled") {
    con.query(
      "SELECT w.id, w.user_name, w.balance, w.reason, b.account_no, b.account_holder_name, b.account_type, b.bankname, b.ifsc_code, upi.name as upiname, upi.UPI_id, num.name, num.number, w.paytype, W.status, w.date  FROM colorgame.withdrawal as w left JOIN colorgame.userbankdeatils as b ON CASE WHEN w.paytype = 'Bank Transfer' THEN w.paymethod_id = b.id ELSE NULL END left JOIN colorgame.userupidetails as upi ON CASE WHEN w.paytype = 'UPI Id' THEN w.paymethod_id = upi.id ELSE NULL END left JOIN colorgame.usernumberdetails as num ON CASE WHEN w.paytype = 'Number' THEN w.paymethod_id = num.id ELSE NULL END where w.user_name = ? and w.status = 'Canceled'",
      [req.body.mobile],
      (err, result) => {
        if (err) throw err;
        if (result) {
          res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })));
        }
      }
    );
  } else {
    con.query(
      "SELECT w.id, w.user_name, w.balance, w.reason, b.account_no, b.account_holder_name, b.account_type, b.bankname, b.ifsc_code, upi.name as upiname, upi.UPI_id, num.name, num.number, w.paytype, W.status, w.date FROM colorgame.withdrawal as w left JOIN colorgame.userbankdeatils as b ON CASE WHEN w.paytype = 'Bank Transfer' THEN w.paymethod_id = b.id ELSE NULL END left JOIN colorgame.userupidetails as upi ON CASE WHEN w.paytype = 'UPI Id' THEN w.paymethod_id = upi.id ELSE NULL END left JOIN colorgame.usernumberdetails as num ON CASE WHEN w.paytype = 'Number' THEN w.paymethod_id = num.id ELSE NULL END where w.user_name = ?",
      [req.body.mobile],
      (err, result) => {
        if (err) throw err;
        if (result) {
          res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })));
        }
      }
    );
  }
});
app.post("/decline-withdrawal-request", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "UPDATE `withdrawal` SET `reson` = ?, `Approved_declined_By` = ?, `status` = 'Canceled' WHERE `id` = ? AND `user_name` = ?",
    [req.body.reason, req.body.mobile, req.body.id, req.body.mobile],
    (err, resultt) => {
      if (err) throw err;
      if (resultt) {
        con.query(
          "UPDATE `wallet` SET `wallet_balance` = wallet_balance + (SELECT `balance` FROM `withdrawal` WHERE `id` = ?) WHERE `user_name` = ?;",
          [req.body.id, req.body.mobile],
          (err, resultt) => {
            if (err) throw err;
            if (resultt) {
              res.status(200).json(btoa(JSON.stringify({
                error: false,
                status: true,
                massage: "Wallet Update SuccessFully",
              })));
            }
          }
        );
      }
    }
  );
});

// statement
app.post("/get-statement", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  let limit = 10;
  let offset = limit * req.body.page - limit;
  con.query("SELECT s.id, s.bet_or_type, s.period, s.Select, s.bet_from, s.bet_balance, s.total_balance, (select COUNT(*) FROM `statement` WHERE `username` = ?) as count, s.date FROM `statement` s WHERE s.`username` = ? ORDER by s.id DESC LIMIT ? OFFSET ?", [req.body.mobile, req.body.mobile, limit, offset], (err, result) => {
    if (err) {
      throw err;
    }
    if (result) {
      res.status(200).json(btoa(JSON.stringify({
        error: false,
        status: true,
        data: result
      })))
    }
  })
});

app.post('/get-shopping-details', (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT * FROM `items` where `status` = 'Y'", (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })));
    }
  })
});

app.post('/add-to-cart', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT * FROM `cart` WHERE `username` = ? and `item_id` = ?;", [req.body.mobile, req.body.i_id], (err, result) => {
    if (err) throw err;
    if (result.length > 0) {
      con.query("UPDATE `cart` SET `total_item` = (? + 1) WHERE `item_id` = ? and `username` = ?", [result[0].total_item, req.body.i_id, req.body.mobile], (error, resultt) => {
        if (error) throw error;
        if (result) {
          res.status(201).json(btoa(JSON.stringify({ error: false, status: true })))
        }
      })
    } else {
      con.query("INSERT INTO `cart`(`username`, `item_id`, `total_item`) VALUES (?,?,?)", [req.body.mobile, req.body.i_id, 1], (error, resultt) => {
        if (error) throw error;
        if (result) {
          res.status(201).json(btoa(JSON.stringify({ error: false, status: true })))
        }
      })
    }
  })
});
app.post('/update-cart-item', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT * FROM `cart` WHERE `username` = ? and `item_id` = ?;", [req.body.mobile, req.body.i_id], (err, result) => {
    if (err) throw err;
    if (result.length > 0) {
      if (req.body.type == "max") {
        con.query("UPDATE `cart` SET `total_item` = (? + 1) WHERE `item_id` = ? and `username` = ?", [result[0].total_item, req.body.i_id, req.body.mobile], (error, resultt) => {
          if (error) throw error;
          if (resultt) {
            res.status(201).json(btoa(JSON.stringify({ error: false, status: true })))
          }
        })
      }
      if (req.body.type == "min") {
        if (result[0].total_item >= 1) {
          con.query("UPDATE `cart` SET `total_item` = (? - 1) WHERE `item_id` = ? and `username` = ?", [result[0].total_item, req.body.i_id, req.body.mobile], (error, resultt) => {
            if (error) throw error;
            if (resultt) {
              res.status(201).json(btoa(JSON.stringify({ error: false, status: true })));
            }
          })
        }
      }
    }
  })
});
app.post("/del-cart-item", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query(
    "DELETE FROM `cart` WHERE `username` = ? and `id` = ?",
    [req.body.mobile, req.body.id],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res
          .status(200)
          .json(btoa(JSON.stringify({ error: false, status: true })));
      }
    }
  );
});
app.post('/get-total-cart-item', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT sum(total_item) as total_item FROM `cart` WHERE `username` = ? and `status` = 'C'", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result[0].total_item })))
    }
  })
});
app.post('/get-cart-item', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT c.id, c.item_id, c.username, i.item_name, i.item_discription, i.item_image, i.item_oprice, i.item_dprice, c.total_item FROM `cart` as c INNER join items as i on c.item_id = i.id WHERE `username` = ? and c.`status` = 'C'", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
    }
  })
});

app.post('/get-order-item', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT c.id, c.item_id, c.username, i.item_name, i.item_discription, i.item_image, i.item_oprice, i.item_dprice, c.total_item, c.order_status, c.order_date, CASE WHEN DATEDIFF(`order_date`, CURDATE()) = 0 THEN 'T' WHEN DATEDIFF(`order_date`, CURDATE()) > 0 THEN 'U' WHEN DATEDIFF(`order_date`, CURDATE()) < 0 THEN 'P' ELSE 'not yet' END AS date_da FROM `cart` as c INNER join items as i on c.item_id = i.id WHERE `username` = ? and c.`status` = 'O' ORDER BY `c`.`order_date` DESC", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
    }
  })
});
app.post('/add-order', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  date = new Date((new Date()).getFullYear(), (new Date()).getMonth(), (new Date()).getDate() + 7);
  con.query(
    "UPDATE `cart` SET `status` = 'O', `order_date` = ? WHERE `username` = ? and `status` = 'C'",
    [date, req.body.mobile],
    (err, result) => {
      if (err) throw err;
      if (result) {
        res
          .status(200)
          .json(btoa(JSON.stringify({ error: false, status: true })));
      }
    }
  );
});

app.post("/get-current-time", verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  res.json(btoa(JSON.stringify({ error: false, status: true, currentTime: new Date() })));
});

app.post('/get-current-offer', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT  COUNT(`coupan`) as count FROM `deposit` WHERE `user_name` = ? and `coupan` = 'First' and (`status` = 'Success' OR `status` = 'Pending')", [req.body.mobile], (err, result) => {
    if (err) { throw err; }
    if (result[0].count == 0) {
      con.query("SELECT * FROM `payment_bonus` WHERE `status` = 'Y' ORDER BY id ASC LIMIT 1 OFFSET 0", (err, result) => {
        if (err) throw err;
        if (result) {
          res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
        }
      })
    } else {
      con.query("SELECT  COUNT(`coupan`) as count FROM `deposit` WHERE `user_name` = ? and `coupan` = 'SECOND' and (`status` = 'Success' OR `status` = 'Pending')", [req.body.mobile], (err, result) => {
        if (err) { throw err; }
        if (result[0].count == 0) {
          con.query("SELECT * FROM `payment_bonus` WHERE `status` = 'Y' ORDER BY id ASC LIMIT 1 OFFSET 1", (err, result) => {
            if (err) throw err;
            if (result) {
              res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
            }
          })
        } else {
          con.query("SELECT  COUNT(`coupan`) as count FROM `deposit` WHERE `user_name` = ? and `coupan` = 'THIRD' and (`status` = 'Success' OR `status` = 'Pending')", [req.body.mobile], (err, result) => {
            if (err) { throw err; }
            if (result[0].count == 0) {
              con.query("SELECT * FROM `payment_bonus` WHERE `status` = 'Y' ORDER BY id ASC LIMIT 1 OFFSET 2", (err, result) => {
                if (err) throw err;
                if (result) {
                  res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
                }
              })
            } else {
              con.query("SELECT  COUNT(`coupan`) as count FROM `deposit` WHERE `user_name` = ? and `coupan` = 'FOURTH' and (`status` = 'Success' OR `status` = 'Pending')", [req.body.mobile], (err, result) => {
                if (err) { throw err; }
                if (result[0].count == 0) {
                  con.query("SELECT * FROM `payment_bonus` WHERE `status` = 'Y' ORDER BY id ASC LIMIT 1 OFFSET 3", (err, result) => {
                    if (err) throw err;
                    if (result) {
                      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
                    }
                  })
                } else {
                  con.query("SELECT  COUNT(`coupan`) as count FROM `deposit` WHERE `user_name` = ? and `coupan` = 'FIFTH' and (`status` = 'Success' OR `status` = 'Pending')", [req.body.mobile], (err, result) => {
                    if (err) { throw err; }
                    if (result[0].count == 0) {
                      con.query("SELECT * FROM `payment_bonus` WHERE `status` = 'Y' ORDER BY id ASC LIMIT 1 OFFSET 4", (err, result) => {
                        if (err) throw err;
                        if (result) {
                          res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
                        }
                      })
                    } else {
                      con.query("SELECT * FROM `payment_bonus` WHERE `status` = 'Y' ORDER BY id ASC LIMIT 100 OFFSET 5", (err, result) => {
                        if (err) throw err;
                        if (result) {
                          res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
                        }
                      })
                    }
                  })
                }
              })
            }
          })
        }
      })
    }
  })
});
app.post('/check-coupon-code', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT * FROM `payment_bonus` WHERE `offer_name` = ? AND `status` = 'Y'", [req.body.code], (err, result) => {
    if (err) throw err;
    if (result.length > 0) {
      if (parseInt(req.body.balance) >= parseInt(result[0].amount_start) && parseInt(req.body.balance) <= parseInt(result[0].amount_end)) {
        res.status(200).json(btoa(JSON.stringify({ error: false, status: true, massage: "Apply SuccessFully", })));
      } else {
        res.status(200).json(btoa(JSON.stringify({ error: true, status: false, massage: "Invalid Coupon Code", })));
      }
    } else {
      res.status(200).json(btoa(JSON.stringify({ error: true, status: false, massage: "Invalid Coupon Code", })));
    }
  })
});

// agents
app.post('/get-today-income', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT SUM(`amount`) as agents_wallet FROM `agents_statement` WHERE `mobile` = ? and DATE(`date`) = CURDATE();", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
    }
  })
});
app.post('/get-total-income', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT SUM(`amount`) as agents_wallet FROM `agents_statement` WHERE `mobile` = ?;", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
    }
  })
});
app.post('/get-total-invite', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT COUNT(*) as agents_wallet FROM `user_details` WHERE `reffer_by` = (SELECT `reffer_code` FROM `user_details` WHERE `user_name` = ?)", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
    }
  })
});
app.post('/get-today-invite', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT COUNT(*) as agents_wallet FROM `user_details` WHERE `reffer_by` = (SELECT `reffer_code` FROM `user_details` WHERE `user_name` = ?) and DATE(`date`) = CURDATE();", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
    }
  })
});
app.post('/get-total-invite-level', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("select(SELECT COUNT(*) FROM`user_level` WHERE`level_1` = (SELECT`reffer_code` FROM`user_details` WHERE`user_name` = ?)) as level_1, (SELECT COUNT(*) FROM `user_level` WHERE`level_2` = (SELECT`reffer_code` FROM `user_details` WHERE`user_name` = ?)) as level_2, (SELECT COUNT(*) FROM `user_level` WHERE`level_3` = (SELECT`reffer_code` FROM `user_details` WHERE`user_name` = ?)) as level_3, (SELECT COUNT(*) FROM `user_level` WHERE`level_4` = (SELECT`reffer_code` FROM `user_details` WHERE`user_name` = ?)) as level_4, (SELECT COUNT(*) FROM `user_level` WHERE`level_5` = (SELECT`reffer_code` FROM `user_details` WHERE`user_name` = ?)) as level_5, (SELECT COUNT(*) FROM `user_level` WHERE`level_6` = (SELECT`reffer_code` FROM `user_details` WHERE`user_name` = ?)) as level_6;", [req.body.mobile, req.body.mobile, req.body.mobile, req.body.mobile, req.body.mobile, req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
    }
  })
});
app.post('/get-total-invite-level-all', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT ul.id,IF((SELECT `reffer_code` FROM `user_details` WHERE `user_name` = ?) = ul.level_1, 'Level 1', IF((SELECT `reffer_code` FROM `user_details` WHERE `user_name` = ?) = ul.level_2, 'Level 2', 'Level 3')) as level,ud.uid,ud.date FROM `user_level` as ul INNER join `user_details` as ud on ul.user_reffral = ud.reffer_code WHERE (SELECT `reffer_code` FROM `user_details` WHERE `user_name` = ?) IN (ul.`level_1`,ul.`level_2`,ul.`level_3`);", [req.body.mobile, req.body.mobile, req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })));
    }
  })
});
app.post('/get-reffral-code', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT `reffer_code` FROM `user_details` WHERE `user_name` = ?", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
    }
  })
});
app.post('/get-daily-income', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT ass.id, ud.uid, ass.amount, ass.discription, ass.date FROM `agents_statement` as ass INNER join `user_details` as ud on ass.mobile = ud.user_name WHERE ass.`mobile` = ?;", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })));
    }
  })
});
app.post('/get-today-total-bet', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT count(*) as count_v FROM `bet-table` WHERE `username` = ? and DATE(`date`) = CURDATE();", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
    }
  })
});
app.post('/check-first-deposit', verifytoken, (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT * FROM `deposit` WHERE `status` = 'Success' and `user_name` = ?", [req.body.mobile], (err, result) => {
    if (err) throw err;
    if (result.length > 0) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: true })));
    } else {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: false })));
    }
  })
});



// sco-content
app.post('/get-page-title', (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT * FROM `page_name` WHERE `name` = ?;", [req.body.name], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
    }
  })
});
app.post('/get-page-sco-content', (req, res) => {
  req.body = JSON.parse(atob(req.body.data));
  con.query("SELECT * FROM `sco_content` WHERE `page_id` =  ?;", [req.body.id], (err, result) => {
    if (err) throw err;
    if (result) {
      res.status(200).json(btoa(JSON.stringify({ error: false, status: true, data: result })))
    }
  })
});

function verifytoken(req, res, next) {
  const bearerHeader = req.headers["authorization"];
  if (typeof bearerHeader !== "undefined") {
    const bearer = bearerHeader.split(" ");
    const bearerToken = bearer[1];
    req.token = bearerToken;
    jwt.verify(req.token, process.env.SECRET_KEY_USER, (err, auth) => {
      if (err) {
        res.status(403).send('Token Expire');
      } else {
        if ((req.body.mobile) != undefined) {
          if (auth.username == req.body.mobile) {
            next();
          } else {
            res.status(403).send("false");
          }
        }
        if ((req.body.data) != undefined) {
          if ((auth.username == JSON.parse(atob(req.body.data)).mobile)) {
            next();
          } else {
            res.status(403).send("false");
          }
        }
      }
    });
  } else {
    res.sendStatus(403);
  }
}
function code() {
  let x = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  let a = "";
  for (let index = 0; index < 8; index++) {
    a += x[Math.floor(Math.random() * x.length)];
  }
  con.query(
    "select * from user_details where `reffer_code` = ?",
    [a],
    (err, result) => {
      if (err) throw err;
      if (result.length > 0) {
        code();
      } else {
        return a;
      }
    })
  return a;
}
function reffer(ba, ab) {
  con.query("SELECT IFNULL(ud.`reffer_by`, 0) as ref FROM `user_details` as ud WHERE ud.`reffer_code` = ?", [ab], (err, level1) => {
    if (err) throw err;
    if (level1[0].ref == 0) {
      con.query('INSERT INTO `user_level`(`user_reffral`, `level_1`) VALUES (?,?)', [ba, ab]);
    } else {
      con.query("SELECT IFNULL(ud.`reffer_by`, 0) as reff FROM `user_details` as ud WHERE ud.`reffer_code` = ?", [level1[0].ref], (err, level2) => {
        if (err) throw err;
        if (level2[0].reff == 0) {
          con.query('INSERT INTO `user_level`(`user_reffral`, `level_1`, `level_2`) VALUES (?,?,?)', [ba, ab, level1[0].reff]);
        } else {
          con.query("SELECT IFNULL(ud.`reffer_by`, 0) as reff FROM `user_details` as ud WHERE ud.`reffer_code` = ?", [level2[0].reff], (err, level3) => {
            if (err) throw err;
            if (level3[0].reff == 0) {
              con.query('INSERT INTO `user_level`(`user_reffral`, `level_1`, `level_2`, `level_3`) VALUES (?,?,?,?)', [ba, ab, level1[0].ref, level2[0].reff]);
            } else {
              con.query("SELECT IFNULL(ud.`reffer_by`, 0) as reff FROM `user_details` as ud WHERE ud.`reffer_code` = ?", [level3[0].reff], (err, level4) => {
                if (err) throw err;
                if (level4[0].reff == 0) {
                  con.query('INSERT INTO `user_level`(`user_reffral`, `level_1`, `level_2`, `level_3`, `level_4`) VALUES (?,?,?,?,?)', [ba, ab, level1[0].ref, level2[0].reff, level3[0].reff]);
                } else {
                  con.query("SELECT IFNULL(ud.`reffer_by`, 0) as reff FROM `user_details` as ud WHERE ud.`reffer_code` = ?", [level4[0].reff], (err, level5) => {
                    if (err) throw err;
                    if (level5[0].reff == 0) {
                      con.query('INSERT INTO `user_level`(`user_reffral`, `level_1`, `level_2`, `level_3`, `level_4`, `level_5`) VALUES (?,?,?,?,?,?)', [ba, ab, level1[0].ref, level2[0].reff, level3[0].reff, level4[0].reff]);
                    } else {
                      con.query('INSERT INTO `user_level`(`user_reffral`, `level_1`, `level_2`, `level_3`, `level_4`, `level_5`, `lavel_6`) VALUES (?,?,?,?,?,?,?)', [ba, ab, level1[0].ref, level2[0].reff, level3[0].reff, level4[0].reff, level5[0].reff]);
                    }
                  })
                }
              })
            }
          })
        }
      })
    }
  })
}
function agent(amount, user) {
  con.query("SELECT `reffer_code` as rc FROM `user_details` WHERE `user_name` = ?", [user], (err, result) => {
    if (err) throw err;
    if (result) {
      con.query("SELECT * FROM `user_level` WHERE `user_reffral` = ?", [result[0].rc], (err, level1) => {
        if (err) throw err;
        const percentage2 = ((5 / 100) * parseFloat(amount)).toFixed(2);
        const percentage3 = ((3 / 100) * parseFloat(amount)).toFixed(2);
        const percentage4 = ((2 / 100) * parseFloat(amount)).toFixed(2);
        const percentage5 = ((2 / 100) * parseFloat(amount)).toFixed(2);
        const percentage6 = ((1 / 100) * parseFloat(amount)).toFixed(2);
        const percentage7 = ((1 / 100) * parseFloat(amount)).toFixed(2);
        if (level1[0].level_1) {
          con.query("UPDATE `wallet` SET `agents_wallet` = `agents_wallet` + ? WHERE `user_name` = (SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?)", [percentage2, level1[0].level_1]);
          con.query("INSERT INTO `agents_statement`(`mobile`, `amount`, `discription`) VALUES ((SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?), ?, ?)", [level1[0].level_1, percentage2, 'Level 1']);
          if (level1[0].level_2 != null) {
            con.query("UPDATE `wallet` SET `agents_wallet` = `agents_wallet` + ? WHERE `user_name` = (SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?)", [percentage3, level1[0].level_2]);
            con.query("INSERT INTO `agents_statement`(`mobile`, `amount`, `discription`) VALUES ((SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?), ?, ?)", [level1[0].level_2, percentage3, 'Level 2']);
            if (level1[0].level_3 != null) {
              con.query("UPDATE `wallet` SET `agents_wallet` = `agents_wallet` + ? WHERE `user_name` = (SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?)", [percentage4, level1[0].level_3]);
              con.query("INSERT INTO `agents_statement`(`mobile`, `amount`, `discription`) VALUES ((SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?), ?, ?)", [level1[0].level_3, percentage4, 'Level 3']);
              if (level1[0].level_4 != null) {
                con.query("UPDATE `wallet` SET `agents_wallet` = `agents_wallet` + ? WHERE `user_name` = (SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?)", [percentage5, level1[0].level_4]);
                con.query("INSERT INTO `agents_statement`(`mobile`, `amount`, `discription`) VALUES ((SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?), ?, ?)", [level1[0].level_4, percentage5, 'Level 4']);
                if (level1[0].level_5 != null) {
                  con.query("UPDATE `wallet` SET `agents_wallet` = `agents_wallet` + ? WHERE `user_name` = (SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?)", [percentage6, level1[0].level_5]);
                  con.query("INSERT INTO `agents_statement`(`mobile`, `amount`, `discription`) VALUES ((SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?), ?, ?)", [level1[0].level_5, percentage6, 'Level 5']);
                  if (level1[0].level_6 != null) {
                    con.query("UPDATE `wallet` SET `agents_wallet` = `agents_wallet` + ? WHERE `user_name` = (SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?)", [percentage7, level1[0].level_6]);
                    con.query("INSERT INTO `agents_statement`(`mobile`, `amount`, `discription`) VALUES ((SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?), ?, ?)", [level1[0].level_6, percentage7, 'Level 6']);
                  } else {
                    con.query("UPDATE `wallet` SET `agents_wallet` = `agents_wallet` + ? WHERE `user_name` = (SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?)", [((parseFloat(amount)) - percentage7).toFixed(2), level1[0].level_1]);
                    con.query("INSERT INTO `agents_statement`(`mobile`, `amount`, `discription`) VALUES ((SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?), ?, ?)", [level1[0].level_1, ((parseFloat(amount)) - percentage7).toFixed(2), 'Level 1']);
                  }
                } else {
                  con.query("UPDATE `wallet` SET `agents_wallet` = `agents_wallet` + ? WHERE `user_name` = (SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?)", [((parseFloat(amount)) - percentage6).toFixed(2), level1[0].level_1]);
                  con.query("INSERT INTO `agents_statement`(`mobile`, `amount`, `discription`) VALUES ((SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?), ?, ?)", [level1[0].level_1, ((parseFloat(amount)) - percentage6).toFixed(2), 'Level 1']);
                }
              } else {
                con.query("UPDATE `wallet` SET `agents_wallet` = `agents_wallet` + ? WHERE `user_name` = (SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?)", [((parseFloat(amount)) - percentage5).toFixed(2), level1[0].level_1]);
                con.query("INSERT INTO `agents_statement`(`mobile`, `amount`, `discription`) VALUES ((SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?), ?, ?)", [level1[0].level_1, ((parseFloat(amount)) - percentage5).toFixed(2), 'Level 1']);
              }
            } else {
              con.query("UPDATE `wallet` SET `agents_wallet` = `agents_wallet` + ? WHERE `user_name` = (SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?)", [((parseFloat(amount)) - percentage4).toFixed(2), level1[0].level_1]);
              con.query("INSERT INTO `agents_statement`(`mobile`, `amount`, `discription`) VALUES ((SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?), ?, ?)", [level1[0].level_1, ((parseFloat(amount)) - percentage4).toFixed(2), 'Level 1']);
            }
          } else {
            con.query("UPDATE `wallet` SET `agents_wallet` = `agents_wallet` + ? WHERE `user_name` = (SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?)", [((parseFloat(amount)) - percentage3).toFixed(2), level1[0].level_1]);
            con.query("INSERT INTO `agents_statement`(`mobile`, `amount`, `discription`) VALUES ((SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?), ?, ?)", [level1[0].level_1, ((parseFloat(amount)) - percentage3).toFixed(2), 'Level 1']);
          }
        } else {
          con.query("UPDATE `wallet` SET `agents_wallet` = `agents_wallet` + ? WHERE `user_name` = (SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?)", [((parseFloat(amount)) - percentage2).toFixed(2), level1[0].level_1]);
          con.query("INSERT INTO `agents_statement`(`mobile`, `amount`, `discription`) VALUES ((SELECT `user_name` FROM `user_details` WHERE `reffer_code` = ?), ?, ?)", [level1[0].level_1, ((parseFloat(amount)) - percentage2).toFixed(2), 'Level 1']);
        }
      })
    }
  })
}
module.exports = app;